VÉLORA Fashion Storefront — Final Project

Files:
- index.html: page structure and content
- style.css: responsive styling, layout, animation, and visual design
- script.js: product rendering, filters, search, wishlist, cart, newsletter, and demo checkout

How to run:
1. Extract the ZIP folder.
2. Open the folder in Visual Studio Code.
3. Open index.html with Live Server (recommended), or double-click index.html.
4. Internet connection is required for Google Fonts, Lucide icons, and remote Unsplash images.

Note:
This is a front-end demo. Cart actions work in the browser, but checkout/account are demonstration interactions and are not connected to a real payment or backend.
